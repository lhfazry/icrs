# Indonesian Car Retrieval System > 2025-06-07 5:56am
https://universe.roboflow.com/rumah-coding/indonesian-car-retrieval-system

Provided by a Roboflow user
License: CC BY 4.0

